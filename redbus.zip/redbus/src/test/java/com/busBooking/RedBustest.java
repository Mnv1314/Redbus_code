package com.busBooking;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class RedBustest {
	
	
	@Test
	public void bookBusTicket() {
		
		String from = "Miyapur";
		String to = "Bangalore";
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.redbus.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebElement fromLocation = driver.findElement(By.xpath("//input[@id='src']"));
		WebElement toLocation  = driver.findElement(By.xpath("//input[@id='dest']"));
		fromLocation.sendKeys(from);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		List<WebElement> fromList = driver.findElements(By.xpath("//div[@id='autoSuggestContainer']//following::li/div/text"));
		for(int i=0;i<fromList.size();i++) {
			if(fromList.get(i).getText().trim().equalsIgnoreCase(from)) {
				fromList.get(i).click();
				break;
			}
		}
		
		toLocation.sendKeys(to);
		List<WebElement> toList = driver.findElements(By.xpath("//div[@id='autoSuggestContainer']//following::li/div/text"));
		for(int i=0;i<toList.size();i++) {
			if(toList.get(i).getText().trim().equalsIgnoreCase(to)) {
				toList.get(i).click();
				break;
			}
		}
		
		
		
		WebElement calendar = driver.findElement(By.xpath("//span[@class='dateText']"));
		calendar.click();
		WebElement nextIcon = driver.findElement(By.xpath("//*[@id='Layer_1']"));
		
		String travelDate = "Oct 29 2024";
		String[] ch = travelDate.split(" ");
		String mm = ch[0];
		String dd = ch[1];
		String yy = ch[2];	
		String month = driver.findElement(By.xpath("(//div[@class='DayNavigator__IconBlock-qj8jdz-2 iZpveD'])[2]")).getText();
		List<WebElement> days = driver.findElements(By.xpath("//span[contains(@class,'DayTiles__CalendarDaysSpan')]"));
		for(int i=0;i<=12;i++) {
			if(month.contains(mm)) {
				for(int j=0;j<=days.size();j++) {
					if(days.get(j).getText().trim().equalsIgnoreCase(dd)) {
						days.get(j).click();
						break;
					}
					
				}
			}
			else {
				nextIcon.click();
			}
			break;
		}
		
		WebElement searchBus = driver.findElement(By.xpath("//button[@id='search_button']"));
		searchBus.click();
		driver.findElement(By.xpath("//div[normalize-space()='View Buses']")).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		List<WebElement> viewSeats = driver.findElements(By.xpath("//div[normalize-space()='View Seats']"));
		Actions action = new Actions(driver);
		action.moveToElement(viewSeats.get(0));
		viewSeats.get(0).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		WebElement selectSeat = driver.findElement(By.xpath("//div[contains(text(),'D3')]"));
		selectSeat.click();
		
		List<WebElement> boardingPoint = driver.findElements(By.xpath("//div[@class='radio-unchecked']"));
		boardingPoint.get(0).click();
		boardingPoint.get(33).click();
		
		WebElement proceedToBook = driver.findElement(By.xpath("//button[normalize-space()='Proceed to book']"));
		proceedToBook.click();
		
		List<WebElement> details = driver.findElements(By.xpath("//input[contains(@id,'seatno')]"));
		details.get(0).sendKeys("Manoj");
		details.get(1).sendKeys("30");
		details.get(2).sendKeys("dummy@gmail.com");
		details.get(3).sendKeys("8143723162");
		WebElement residence = driver.findElement(By.xpath("//input[@role='presentation']"));
		residence.sendKeys("Telangana");
		WebElement notOpt = driver.findElement(By.xpath("//input[@id='insuranceNotOpted_rap']"));
		notOpt.click();
		WebElement proceedToPay = driver.findElement(By.xpath("//input[@value='Proceed to pay']"));
		proceedToPay.click();

		//driver.quit();
	}

}
